# crypto_app/consumers.py
import json
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import UserAccount, Transaction
from channels.db import database_sync_to_async

class TransactionConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # All clients connect to this "transactions" group
        self.room_group_name = 'transactions'

        # Join the room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        # Leave the group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        # Receive transaction data from WebSocket (JSON format)
        data = json.loads(text_data)
        sender_address = data['sender']
        recipient_address = data['recipient']
        amount = data['amount']

        # Update the transaction in the database and balances
        await self.sync_transaction(sender_address, recipient_address, amount)

    @database_sync_to_async
    def sync_transaction(self, sender_address, recipient_address, amount):
        # Update sender and recipient balances in the database
        sender_account = UserAccount.objects.get(eth_address=sender_address)
        recipient_account = UserAccount.objects.get(eth_address=recipient_address)

        if sender_account.eth_balance >= amount:
            sender_account.eth_balance -= amount
            recipient_account.eth_balance += amount

            sender_account.save()
            recipient_account.save()

            # Create a transaction record
            Transaction.objects.create(
                sender=sender_account,
                recipient_address=recipient_address,
                amount=amount,
                currency='ETH'
            )

            return {'success': True, 'message': f"{amount} ETH sent successfully."}
        else:
            return {'success': False, 'message': 'Insufficient balance'}

    # Send the transaction updates to all clients
    async def send_transaction_update(self, event):
        # Send the transaction update to the WebSocket clients
        await self.send(text_data=json.dumps({
            'message': event['message']
        }))
