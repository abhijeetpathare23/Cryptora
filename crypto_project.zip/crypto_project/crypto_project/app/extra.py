import random
import string
from web3 import Web3

# In-memory storage for balances, transactions, and user data
accounts = {}
transactions = []
active_user = None  # To track the logged-in user

# Helper function to generate a dummy Bitcoin address
def generate_btc_account():
    address = "1" + "".join(random.choices(string.ascii_letters + string.digits, k=33))
    private_key = "".join(random.choices(string.ascii_letters + string.digits, k=64))
    return address, private_key
from web3 import Web3

# Function to generate a dummy Ethereum account
def generate_dummy_eth_account():
    # Create a random Ethereum account
    account = Web3().eth.account.create()
    eth_address = account.address
    eth_private_key = account.key.hex()  # Save the private key securely
    return eth_address, eth_private_key

# Helper function to generate an Ethereum account
def generate_eth_account():
    account = Web3().eth.account.create()
    return account.address, account.key.hex()

# Create a new account
def create_account():
    global active_user
    print("\n=== Account Creation ===")
    username = input("Enter your name: ")
    phone = input("Enter your phone number: ")

    print("Creating BTC and ETH accounts...")
    btc_address, btc_private_key = generate_btc_account()
    eth_address, eth_private_key = generate_eth_account()

    # Store user info and initial balances
    accounts[username] = {
        "phone": phone,
        "btc": {"address": btc_address, "private_key": btc_private_key, "balance": 1000.0, "transactions": []},
        "eth": {"address": eth_address, "private_key": eth_private_key, "balance": 1000.0, "transactions": []}
    }

    print(f"Account created for {username}")
    print(f"BTC Address: {btc_address}\nETH Address: {eth_address}")

    # Set the active user session
    active_user = username

# Login as an existing user
def login():
    global active_user
    print("\n=== Login ===")
    username = input("Enter your username: ")

    if username in accounts:
        active_user = username
        print(f"Logged in as {username}")
    else:
        print("Username not found. Please register first.")

# Logout
def logout():
    global active_user
    active_user = None
    print("Logged out successfully.")
    sec

# Display account balances for the logged-in user
def show_balances():
    if not active_user:
        print("You must be logged in to view balances.")
        return
    print(f"\n=== Account Balances for {active_user} ===")
    user_data = accounts[active_user]
    print(f"BTC Address: {user_data['btc']['address']} | Balance: {user_data['btc']['balance']} BTC")
    print(f"ETH Address: {user_data['eth']['address']} | Balance: {user_data['eth']['balance']} ETH")

# Simulate sending a transaction
def send_transaction():
    if not active_user:
        print("You must be logged in to send transactions.")
        return

    print("\n=== Send Transaction ===")
    currency = input("Enter currency (BTC, ETH): ").upper()
    if currency not in ['BTC', 'ETH']:
        print("Invalid currency!")
        return

    # Automatically use the logged-in user's address as the sender address
    sender_address = accounts[active_user][currency.lower()]["address"]

    recipient_address = input("Enter Recipient Address: ")
    amount = float(input("Enter Amount to Send: "))

    user_data = accounts[active_user]
    if sender_address != user_data[currency.lower()]["address"]:
        print("Sender address does not match your account address.")
        return

    if user_data[currency.lower()]["balance"] < amount:
        print("Insufficient balance!")
        return

    # Deduct from sender
    user_data[currency.lower()]["balance"] -= amount

    # Add to recipient (create account if not exists)
    for user, data in accounts.items():
        if recipient_address == data[currency.lower()]["address"]:
            accounts[user][currency.lower()]["balance"] += amount
            break
    else:
        print("Recipient address not found. Creating new account for recipient.")
        new_address, _ = generate_btc_account() if currency == 'BTC' else generate_eth_account()
        accounts[recipient_address] = {
            "btc": {"address": new_address, "balance": amount, "transactions": []},
            "eth": {"address": new_address, "balance": amount, "transactions": []}
        }

    # Log the transaction
    transaction = {
        "currency": currency,
        "sender": sender_address,
        "recipient": recipient_address,
        "amount": amount
    }
    user_data[currency.lower()]["transactions"].append(transaction)

    print(f"Transaction successful! Sent {amount} {currency} from {sender_address} to {recipient_address}.")


# Show transaction history for the logged-in user
def show_transactions():
    if not active_user:
        print("You must be logged in to view transactions.")
        return
    user_data = accounts[active_user]
    print(f"\n=== Transaction History for {active_user} ===")
    for currency in ['btc', 'eth']:
        print(f"\n{currency.upper()} Transactions:")
        for tx in user_data[currency]["transactions"]:
            print(f"  {tx['sender']} -> {tx['recipient']}: {tx['amount']} {tx['currency']}")

# Main menu
def main():
    while True:
        print("\n=== Cryptocurrency Offline Simulator ===")
        if active_user:
            print(f"Logged in as {active_user}")
            print("1. Show Balances")
            print("2. Send Transaction")
            print("3. Show Transactions")
            print("4. Logout")
            print("5. Exit")
            choice = input("Select an option: ")

            if choice == "1":
                show_balances()
            elif choice == "2":
                send_transaction()
            elif choice == "3":
                show_transactions()
            elif choice == "4":
                logout()
            elif choice == "5":
                break
            else:
                print("Invalid choice!")
        else:
            print("1. Login")
            print("2. Register (Create a new account)")
            print("3. Exit")
            choice = input("Select an option: ")

            if choice == "1":
                login()
            elif choice == "2":
                create_account()
            elif choice == "3":
                break
            else:
                print("Invalid choice!")

if __name__ == "__main__":
    # some code

    main()