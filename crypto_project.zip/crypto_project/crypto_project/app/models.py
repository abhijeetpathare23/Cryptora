
from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
import re


def validate_eth_address(value):
    if not re.match(r'^0x[a-fA-F0-9]{40}$', value):
        raise ValidationError(f"{value} is not a valid Ethereum address.")

# UserAccount model
class UserAccount(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)  # One-to-one relationship with User
    eth_address = models.CharField(max_length=42, unique=True, validators=[validate_eth_address])  # Ethereum address
    eth_balance = models.DecimalField(max_digits=18, decimal_places=8, default=1000.0)  # Ethereum balance
    private_key = models.CharField(max_length=64)  # Ethereum private key

    def __str__(self):
        return f"{self.user.username}'s Account"


# Transaction model
class Transaction(models.Model):
    sender = models.ForeignKey(UserAccount, related_name='sent_transactions_list', on_delete=models.CASCADE)  # Sender user
    recipient_address = models.CharField(max_length=42, validators=[validate_eth_address])  # Ethereum address of the recipient
    amount = models.DecimalField(max_digits=18, decimal_places=8)  # Amount of ETH sent
    currency = models.CharField(max_length=3, choices=[('ETH', 'ETH')], default='ETH')  # Currency type
    timestamp = models.DateTimeField(auto_now_add=True)  # Time when the transaction was made

    def __str__(self):
        return f"{self.sender.user.username} sent {self.amount} {self.currency} to {self.recipient_address} on {self.timestamp}"

    
    # WalletTransaction model
class WalletTransaction(models.Model):
    user_account = models.ForeignKey(UserAccount, on_delete=models.CASCADE)  # User associated with the transaction
    transaction_type = models.CharField(max_length=20, choices=[('SEND', 'Send'), ('RECEIVE', 'Receive')])  # Type of transaction
    amount = models.DecimalField(max_digits=18, decimal_places=8)  # Amount of ETH transferred
    timestamp = models.DateTimeField(auto_now_add=True)  # Timestamp of the transaction
    recipient_address = models.CharField(max_length=42, blank=True, null=True, validators=[validate_eth_address])  # Recipient's address
    sender_address = models.CharField(max_length=42, blank=True, null=True, validators=[validate_eth_address])  # Sender's address

    def __str__(self):
        return f"{self.transaction_type} {self.amount} ETH on {self.timestamp}"

