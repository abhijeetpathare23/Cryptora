# crypto_app/urls.py
from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView


urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('balance/', views.show_balance, name='show_balance'),
    path('send_transaction/', views.send_transaction, name='send_transaction'),
    path('show_transactions/', views.show_transactions, name='show_transactions'),  # Add this line
    path('dashboard/', views.dashboard, name='dashboard'),  # Add this line
    path('dashboards/', views.dashboards, name='dashboards'),  # Add this line
    # path('logout_view/', views.logout_view, name='logout_view'),  # Add this line
    path('log_out/', LogoutView.as_view(next_page='home'), name='logout_view'),
]
