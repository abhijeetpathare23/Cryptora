
from web3 import Web3
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from .models import UserAccount, Transaction
import random
import string
from django.contrib.auth.models import User 
from decimal import Decimal
from .models import UserAccount
from django.contrib.auth import logout
import logging

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

@csrf_exempt  # You can remove this if you're using CSRF tokens
def sync_transactions(request):
    if request.method == 'POST':
        # Parse the incoming transaction data
        data = json.loads(request.body)
        transactions = data.get('transactions', [])

        for transaction in transactions:
            sender_address = transaction.get('sender')
            recipient_address = transaction.get('recipient')
            amount = transaction.get('amount')

            # Here, you would add logic to save these transactions in the database
            # and update user balances accordingly.
            # This is just a basic example for demonstration.

            # Example:
            # Update the sender and recipient accounts, and create transaction records.
            try:
                sender_account = UserAccount.objects.get(eth_address=sender_address)
                recipient_account = UserAccount.objects.get(eth_address=recipient_address)

                if sender_account.eth_balance >= amount:
                    # Deduct from sender and add to recipient
                    sender_account.eth_balance -= amount
                    recipient_account.eth_balance += amount

                    # Save both sender and recipient accounts
                    sender_account.save()
                    recipient_account.save()

                    # Save the transaction to the database
                    Transaction.objects.create(
                        sender=sender_account,
                        recipient_address=recipient_address,
                        amount=amount,
                        currency='ETH'
                    )

                    # Optionally, delete the offline transaction after processing it
                    # For simplicity, we're not handling this part here.
                else:
                    # If balance is insufficient, handle the error
                    return JsonResponse({'success': False, 'message': 'Insufficient balance'}, status=400)
            
            except UserAccount.DoesNotExist:
                return JsonResponse({'success': False, 'message': 'User account not found'}, status=400)

        return JsonResponse({'success': True}, status=200)

    return JsonResponse({'error': 'Invalid request method'}, status=405)




logger = logging.getLogger(__name__)
w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))


def home(request):
    return render(request, 'home.html')



# Register view

def generate_dummy_eth_address():
    # Generate a dummy Ethereum address for testing (just an example, not real)
    return "0x" + ''.join(random.choices(string.hexdigits, k=40))

def generate_dummy_private_key():
    # Generate a dummy private key for testing (just an example, not real)
    return ''.join(random.choices(string.hexdigits, k=64))


def register_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        # Create the user using Django's built-in User model
        user = User.objects.create_user(username=username, password=password)
        
        # Generate an Ethereum address and private key (or use any dummy address for testing)
        eth_address = generate_dummy_eth_address()  # You need to implement this
        private_key = generate_dummy_private_key()  # You need to implement this
        eth_balance = 1000.0  # Default balance
        
        # Create the associated UserAccount
        user_account = UserAccount.objects.create(
            user=user,
            eth_address=eth_address,
            eth_balance=eth_balance,
            private_key=private_key
        )

        # Redirect to login page after successful registration
        messages.success(request, "Registration successful! You can now log in.")
        return redirect('login')  # Make sure the login URL name is 'login'

    return render(request, 'register.html')


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Authenticate the user
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('dashboards')  # Redirect to balance page after successful login
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    
    return render(request, 'login.html')
# Logout view

def logout_view(request):
    if request.method == 'POST':
        logout(request)
        return redirect('login')
    return redirect('home')

# Show balance view

def show_balance(request):
    try:
        user_account = UserAccount.objects.get(user=request.user)
        print(user_account.eth_address)  # Check if address is fetched correctly
    except UserAccount.DoesNotExist:
        user_account = None

    return render(request, 'show_balance.html', {'user_account': user_account})

def send_transaction(request):
    if request.method == 'POST':
        # Get the sender's UserAccount
        sender_account = UserAccount.objects.get(user=request.user)
        
        # Get recipient's Ethereum address and amount to send
        recipient_address = request.POST.get('recipient_address')
        amount = Decimal(request.POST.get('amount'))  # Convert amount to Decimal

        # Find recipient UserAccount by Ethereum address
        recipient_account = UserAccount.objects.get(eth_address=recipient_address)

        # Check if sender has enough balance
        if sender_account.eth_balance >= amount:
            # Subtract from sender and add to recipient
            sender_account.eth_balance -= amount
            recipient_account.eth_balance += amount

            # Save both sender and recipient account
            sender_account.save()
            recipient_account.save()

            # Save the transaction (if using Transaction model)
            Transaction.objects.create(
                sender=sender_account,
                recipient_address=recipient_account.eth_address,
                amount=amount,
                currency='ETH'
            )

            # Success message
            messages.success(request, f"Transaction of {amount} ETH successful!")
        else:
            # Error message if insufficient balance
            messages.error(request, "Insufficient balance to complete the transaction.")
        
        return redirect('show_balance')

    return render(request, 'send_transaction.html')

def show_transactions(request):
    # Get the user's account from the UserAccount model
    user_account = request.user.useraccount
    
    # Get transactions where the user is the sender
    sent_transactions = Transaction.objects.filter(sender=user_account)
    
    # Get transactions where the user is the receiver
    received_transactions = Transaction.objects.filter(recipient_address=user_account.eth_address)
    
    # Pass the sent and received transactions to the template
    return render(request, 'show_transactions.html', {
        'sent_transactions': sent_transactions,
        'received_transactions': received_transactions
    })
def dashboard(request):
    return render(request, 'dashboard.html')
def dashboards(request):
    return render(request, 'dashboards.html')