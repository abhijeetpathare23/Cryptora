from django.contrib import admin

# Register your models here.
from .models import UserAccount,Transaction,WalletTransaction

admin.site.register(UserAccount)
admin.site.register(Transaction)
admin.site.register(WalletTransaction)
